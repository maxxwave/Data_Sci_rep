#!/bin/bash
#rm aici

for i in $(seq 1 1 10)
do

#paste  "att$i/field_map.data"
l=`cat att$i/field_map.data|awk '{printf("%d", $3)}'` 
done
