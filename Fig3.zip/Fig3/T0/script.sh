paste att1/field_map.data att2/field_map.data att3/field_map.data att4/field_map.data att4/field_map.data att5/field_map.data  att6/field_map.data att7/field_map.data att8/field_map.data att9/field_map.data att10/field_map.data >aici 


