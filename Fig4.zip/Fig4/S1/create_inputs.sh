for i in 10 20 30 40 60 70 80 90
do
mkdir T$i
cd T$i

cat<<EOF >input 
# Material parameters:
Ms=477e3
L=200e-9
Ly=50e-9
Lz=5e-9
Aex=1.05e-11
alpha=0.02

Nwires=1


# Field's parameters:
H=0 #A/m
f=500e6

# Simulation's parameters:
Dt=1e-13
totaltime=10e-9
out_time=0.1e-9
integrator=RK4

#Pinning field:
pin=0
Temperature=$i
#spin torque paramters
P=0.0
beta=0.04
j=0 #A/m^2
program=RC
#program=spin_current
#program=Bifurcation

EOF

cat<<EOF >rc_input 
#input filename
file=sine_square_init

#time duration
T=16e-9

#number of virtual nodes
Nv=32

#number of epochs
Ne=3

#learning rate
lr=2.01

#momentum
la=0.5

#field parameters
H0=2500
dH=2000
#regression factor
lambda=0.01

seed=1373
EOF

cp ../sine_square_init . 
cp ../DWPC .
cp ../submit.job .

qsub submit.job
cd .. 
done 

